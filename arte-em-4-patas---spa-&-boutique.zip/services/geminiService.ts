import { GoogleGenAI } from "@google/genai";
import { DogTip } from '../types';

const getGeminiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API Key not found in environment variables");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const generatePetTip = async (): Promise<DogTip | null> => {
  const ai = getGeminiClient();
  if (!ai) return null;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: "Gere uma dica curta, útil e curiosa sobre cuidados com cães (focada em higiene, banho de ozono ou tosquia). Responda em JSON com os campos 'title' e 'content'. O tom deve ser amigável e profissional.",
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) return null;
    
    return JSON.parse(text) as DogTip;
  } catch (error) {
    console.error("Error generating pet tip:", error);
    return null;
  }
};