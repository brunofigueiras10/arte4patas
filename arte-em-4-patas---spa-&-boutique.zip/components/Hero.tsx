import React from 'react';
import { Play, Star, Sparkles, PawPrint } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative pt-32 pb-12 min-h-screen flex flex-col justify-center overflow-hidden bg-[#f3f4f6]">
      
      {/* Background Texture (Dots) */}
      <div className="absolute inset-0 z-0 opacity-[0.05] pointer-events-none" 
           style={{ backgroundImage: 'radial-gradient(#111827 1px, transparent 1px)', backgroundSize: '32px 32px' }}>
      </div>

      {/* Large Organic Background Blob (Right Side) */}
      <div className="absolute top-1/2 right-[-5%] -translate-y-1/2 w-[60vw] h-[60vw] bg-white rounded-full blur-3xl opacity-60 pointer-events-none z-0"></div>

      {/* Decorative Giant Paw (Left Side) */}
      <div className="absolute top-20 -left-20 text-gray-200/50 rotate-[-12deg] pointer-events-none z-0">
         <PawPrint size={400} />
      </div>

      <div className="max-w-7xl mx-auto px-4 w-full z-10 relative">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center">
            
            {/* Left Column: Text Content */}
            <div className="flex flex-col gap-8 max-w-xl relative z-10">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/60 backdrop-blur-sm rounded-full w-fit border border-gray-200 shadow-sm">
                    <span className="w-2 h-2 rounded-full bg-brand-yellow animate-pulse"></span>
                    <span className="text-xs font-bold text-gray-600 tracking-wide uppercase">Novos Banhos de Ozono</span>
                </div>

                <h1 className="text-6xl md:text-8xl font-bold text-gray-900 leading-[1.05] tracking-tight text-center">
                    Dê ao seu Pet <br/>
                    o <span className="italic font-light text-brand-black relative">
                        Amor
                        <svg className="absolute w-full h-3 -bottom-1 left-0 text-brand-yellow opacity-60" viewBox="0 0 100 10" preserveAspectRatio="none">
                            <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="8" fill="none" />
                        </svg>
                    </span> e Carinho que Merece!
                </h1>
                
                <p className="text-gray-600 text-lg md:text-xl leading-relaxed max-w-md font-medium">
                    O bem-estar do seu animal é a nossa prioridade. 
                    Profissionais de confiança, spa premium e muito mimo garantido.
                </p>

                <div className="flex items-center gap-4 mt-4">
                    <button className="bg-gray-900 text-white px-10 py-4 rounded-2xl font-bold text-base hover:bg-brand-yellow hover:scale-105 transition-all shadow-xl shadow-gray-900/20">
                        Agendar Agora
                    </button>
                    <button className="bg-white border-2 border-gray-100 text-gray-900 px-8 py-4 rounded-2xl font-bold text-base hover:border-gray-300 hover:bg-gray-50 transition-all flex items-center gap-3 shadow-lg shadow-gray-200/50">
                        <div className="bg-gray-100 rounded-full p-1.5">
                            <Play size={14} className="text-gray-900 fill-gray-900 ml-0.5" />
                        </div>
                        Ver Vídeo
                    </button>
                </div>

                {/* Trust Indicators */}
                <div className="flex items-center gap-6 pt-4 opacity-80">
                    <div className="flex -space-x-3">
                        {[1,2,3,4].map((i) => (
                            <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-gray-200 overflow-hidden">
                                <img src={`https://i.pravatar.cc/100?img=${i+10}`} alt="User" />
                            </div>
                        ))}
                    </div>
                    <div>
                        <div className="flex text-brand-yellow">
                            {[1,2,3,4,5].map(i => <Star key={i} size={14} fill="currentColor" />)}
                        </div>
                        <p className="text-xs font-bold text-gray-500">4.9/5 de +500 Avaliações</p>
                    </div>
                </div>
            </div>

            {/* Right Column: Image */}
            <div className="relative h-[550px] md:h-[750px] flex items-end justify-center lg:justify-end pb-24 md:pb-48">
                
                {/* Main Image - Scaled Up */}
                <img 
                    src="https://images.unsplash.com/photo-1543466835-00a7907e9de1?q=80&w=1200&auto=format&fit=crop" 
                    alt="Happy Dog" 
                    className="relative z-10 w-[120%] max-w-none md:max-w-2xl object-contain drop-shadow-2xl translate-x-10 md:translate-x-0"
                    style={{maskImage: 'linear-gradient(to bottom, black 85%, transparent 100%)'}}
                />
            </div>
        </div>

    
      </div>
    </div>
  );
};

export default Hero;