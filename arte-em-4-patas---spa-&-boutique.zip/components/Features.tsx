import React, { useState, useEffect } from 'react';
import { Scissors, CloudRain, Star, Info, ChevronLeft, ChevronRight, Sparkles, Instagram, ArrowUpRight } from 'lucide-react';
import { generatePetTip } from '../services/geminiService';
import { DogTip } from '../types';

const Features: React.FC = () => {
  const [tip, setTip] = useState<DogTip | null>(null);
  const [loadingTip, setLoadingTip] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);

  // Initial tip load
  useEffect(() => {
    if (process.env.API_KEY) {
      handleGetTip();
    } else {
        setTip({
            title: "Benefícios do Ozono",
            content: "O banho de ozono ajuda na oxigenação da pele, combate bactérias e deixa o pelo do seu cão incrivelmente macio e brilhante!"
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleGetTip = async () => {
    setLoadingTip(true);
    const newTip = await generatePetTip();
    if (newTip) {
      setTip(newTip);
    }
    setLoadingTip(false);
  };

  const services = [
    {
      title: "Tosquias",
      subtitle: "Estilo & Higiene",
      desc: "Cortes específicos para cada raça ou tosquias higiénicas. Tesouras esterilizadas e muito carinho.",
      icon: Scissors,
      color: "bg-orange-50 text-orange-600",
      borderColor: "hover:border-orange-200"
    },
    {
      title: "Banho Ozono",
      subtitle: "Saúde da Pele",
      desc: "Tecnologia que trata a pele, elimina odores e relaxa o seu pet. Ideal para cães com alergias.",
      icon: CloudRain,
      color: "bg-blue-50 text-blue-600",
      borderColor: "hover:border-blue-200"
    },
    {
      title: "Spa Completo",
      subtitle: "O pacote total",
      desc: "Banho, tosquia, corte de unhas e limpeza de ouvidos. O seu cão sai novo e cheiroso!",
      icon: Star,
      color: "bg-yellow-50 text-yellow-600",
      borderColor: "hover:border-yellow-200"
    }
  ];

  const transformations = [
    {
      id: 1,
      name: 'Boby',
      breed: 'Yorkshire Terrier',
      desc: 'Tosquia de Verão',
      before: 'https://images.unsplash.com/photo-1591769225440-811ad7d6eca6?q=80&w=600&auto=format&fit=crop',
      after: 'https://images.unsplash.com/photo-1517423568366-697553f1e733?q=80&w=600&auto=format&fit=crop',
    },
    {
      id: 2,
      name: 'Luna',
      breed: 'Golden Retriever',
      desc: 'Tratamento de Ozono & Brilho',
      before: 'https://images.unsplash.com/photo-1625316708582-7e3853d56d2f?q=80&w=600&auto=format&fit=crop',
      after: 'https://images.unsplash.com/photo-1552053831-71594a27632d?q=80&w=600&auto=format&fit=crop',
    },
    {
      id: 3,
      name: 'Max',
      breed: 'Caniche',
      desc: 'Corte Tesoura & Estilo',
      before: 'https://images.unsplash.com/photo-1605639156481-244775d6f803?q=80&w=600&auto=format&fit=crop',
      after: 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?q=80&w=600&auto=format&fit=crop',
    }
  ];

   const galleryImages = [
    { src: 'https://images.unsplash.com/photo-1517849845537-4d257902454a?q=80&w=400&auto=format&fit=crop', name: 'Buddy' },
    { src: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?q=80&w=400&auto=format&fit=crop', name: 'Charlie' },
    { src: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?q=80&w=400&auto=format&fit=crop', name: 'Daisy' },
    { src: 'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?q=80&w=400&auto=format&fit=crop', name: 'Cooper' },
    { src: 'https://images.unsplash.com/photo-1588943211346-0908a1fb0b01?q=80&w=400&auto=format&fit=crop', name: 'Luna' },
    { src: 'https://images.unsplash.com/photo-1596492784531-6e6eb5ea92d5?q=80&w=400&auto=format&fit=crop', name: 'Teddy' },
    { src: 'https://images.unsplash.com/photo-1530281700549-e82e7bf110d6?q=80&w=400&auto=format&fit=crop', name: 'Rocky' },
     { src: 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?q=80&w=400&auto=format&fit=crop', name: 'Max' },
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % transformations.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? transformations.length - 1 : prev - 1));
  };

  return (
    <div className="bg-white py-12 md:py-16 px-4 rounded-t-[3rem] relative z-20 -mt-12 shadow-[0_-20px_40px_rgba(0,0,0,0.05)]">
      <div className="max-w-7xl mx-auto">
        
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div className="max-w-xl">
            <span className="text-brand-yellow font-bold tracking-wider text-sm uppercase">Nossos Serviços</span>
            <h2 className="text-4xl md:text-5xl font-black mt-2 text-gray-900 leading-tight">
              Tudo o que o seu pet precisa para <span className="text-gray-400 decoration-brand-yellow underline decoration-4 underline-offset-4">brilhar</span>
            </h2>
          </div>
          <button className="hidden md:flex items-center gap-2 font-bold text-gray-900 hover:text-brand-yellow transition-colors">
            Ver todos os serviços <ArrowUpRight size={20} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-24">
          {services.map((s, idx) => (
            <div key={idx} className={`bg-gray-50 rounded-[32px] p-8 transition-all duration-300 border-2 border-transparent ${s.borderColor} hover:bg-white hover:shadow-2xl hover:-translate-y-2 group cursor-pointer`}>
              <div className="flex justify-between items-start mb-8">
                <div className={`w-14 h-14 ${s.color} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <s.icon size={28} />
                </div>
                <div className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center bg-white opacity-0 group-hover:opacity-100 transition-opacity">
                    <ArrowUpRight size={18} />
                </div>
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900">{s.title}</h3>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-wide mb-3">{s.subtitle}</p>
              <p className="text-gray-500 leading-relaxed text-sm font-medium">{s.desc}</p>
            </div>
          ))}
        </div>

        {/* Before and After Carousel */}
        <div className="mb-24">
          <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-gray-900">Transformações Incríveis</h3>
              <p className="text-gray-500 mt-2">Arraste para ver a magia acontecer</p>
          </div>

          <div className="relative bg-[#f8f9fa] rounded-[48px] p-6 md:p-12 max-w-6xl mx-auto border border-gray-100 shadow-sm">
              {/* Controls */}
              <button 
                onClick={prevSlide} 
                className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-20 bg-white p-4 rounded-full shadow-lg hover:bg-brand-yellow hover:text-white transition-colors border border-gray-100"
                aria-label="Anterior"
              >
                  <ChevronLeft size={24} />
              </button>
              <button 
                onClick={nextSlide} 
                className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-20 bg-white p-4 rounded-full shadow-lg hover:bg-brand-yellow hover:text-white transition-colors border border-gray-100"
                aria-label="Próximo"
              >
                  <ChevronRight size={24} />
              </button>

              {/* Slide Content */}
              <div className="flex flex-col md:flex-row gap-6 md:gap-8 items-center justify-center">
                  
                  {/* Before */}
                  <div className="flex-1 w-full relative group">
                      <span className="absolute top-4 left-4 bg-black/70 text-white px-4 py-1.5 rounded-full text-xs font-bold uppercase backdrop-blur-sm z-10 tracking-widest">Antes</span>
                      <div className="h-64 md:h-[400px] rounded-[32px] overflow-hidden shadow-sm">
                         <img 
                            src={transformations[currentSlide].before} 
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 filter grayscale-[30%] group-hover:grayscale-0" 
                            alt={`Antes da tosquia - ${transformations[currentSlide].name}`} 
                         />
                      </div>
                  </div>

                  {/* Icon/Divider */}
                  <div className="hidden md:flex flex-col items-center gap-2 text-brand-yellow shrink-0">
                       <div className="h-12 w-[2px] bg-gray-200"></div>
                       <Sparkles size={24} className="animate-pulse" />
                       <div className="h-12 w-[2px] bg-gray-200"></div>
                  </div>

                  {/* After */}
                  <div className="flex-1 w-full relative group">
                      <span className="absolute top-4 right-4 bg-brand-yellow text-white px-4 py-1.5 rounded-full text-xs font-bold uppercase backdrop-blur-sm z-10 tracking-widest shadow-lg">Depois</span>
                       <div className="h-64 md:h-[400px] rounded-[32px] overflow-hidden shadow-xl border-4 border-white ring-1 ring-gray-100">
                         <img 
                            src={transformations[currentSlide].after} 
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                            alt={`Depois da tosquia - ${transformations[currentSlide].name}`} 
                         />
                      </div>
                  </div>
              </div>
              
              {/* Caption/Dots */}
              <div className="text-center mt-8">
                  <h4 className="text-2xl font-black text-gray-800 mb-1">{transformations[currentSlide].name}</h4>
                  <p className="text-brand-yellow font-medium text-sm mb-6 uppercase tracking-wide">{transformations[currentSlide].breed} • {transformations[currentSlide].desc}</p>
                  
                  <div className="flex justify-center gap-2">
                      {transformations.map((_, idx) => (
                          <button 
                            key={idx}
                            onClick={() => setCurrentSlide(idx)}
                            className={`h-1.5 rounded-full transition-all duration-300 ${currentSlide === idx ? 'bg-brand-yellow w-8' : 'bg-gray-300 w-2 hover:bg-gray-400'}`}
                            aria-label={`Ir para slide ${idx + 1}`}
                          />
                      ))}
                  </div>
              </div>
          </div>
        </div>

        {/* AI Tip Section */}
        <div className="bg-brand-yellow rounded-[40px] p-8 md:p-12 text-gray-900 relative overflow-hidden mb-24 shadow-xl shadow-yellow-500/20">
            <div className="absolute top-0 right-0 opacity-20 pointer-events-none text-white mix-blend-overlay">
                <Scissors size={400} />
            </div>
            
            <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center gap-8">
                <div className="bg-white/90 p-5 rounded-2xl backdrop-blur-sm shadow-sm">
                    <Info size={32} className="text-brand-dark" />
                </div>
                <div className="flex-1">
                    <h4 className="text-xl font-bold mb-2 flex items-center gap-2">
                        Dica do Dia (AI)
                        {loadingTip && <span className="text-xs font-normal animate-pulse text-gray-700 bg-white/30 px-2 py-0.5 rounded-full">A pensar...</span>}
                    </h4>
                    {tip ? (
                        <div>
                            <p className="font-black text-2xl text-gray-900 mb-2">{tip.title}</p>
                            <p className="text-gray-900/80 max-w-2xl font-medium leading-relaxed">{tip.content}</p>
                        </div>
                    ) : (
                        <p className="text-gray-900 font-medium">Descubra como melhorar a vida do seu melhor amigo.</p>
                    )}
                </div>
                <button 
                    onClick={handleGetTip}
                    disabled={loadingTip}
                    className="bg-gray-900 text-white px-8 py-4 rounded-xl font-bold hover:bg-gray-800 transition-all disabled:opacity-50 shadow-lg"
                >
                    Nova Dica
                </button>
            </div>
        </div>

        {/* NEW GALLERY SECTION */}
        <div className="mb-12">
            <div className="flex flex-col md:flex-row justify-between items-end mb-10 gap-4">
                <div>
                    <h3 className="text-3xl font-bold text-gray-900">Galeria dos Felizes</h3>
                    <p className="text-gray-500 mt-2">Nossos clientes satisfeitos após um dia de spa.</p>
                </div>
                 <div className="flex items-center gap-2 text-brand-yellow font-bold text-sm cursor-pointer hover:underline group">
                    <div className="p-2 bg-yellow-50 rounded-full group-hover:bg-brand-yellow group-hover:text-white transition-colors">
                        <Instagram size={18} />
                    </div>
                    Siga-nos no Instagram
                 </div>
            </div>

            <div className="flex gap-6 overflow-x-auto pb-12 snap-x px-4 -mx-4 no-scrollbar">
                {galleryImages.map((img, idx) => (
                    <div key={idx} className="min-w-[280px] md:min-w-[320px] h-[400px] rounded-[32px] overflow-hidden relative shadow-lg snap-center group cursor-pointer border-[6px] border-white bg-gray-100">
                        <img src={img.src} alt={img.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-8">
                            <p className="text-white font-black text-3xl translate-y-4 group-hover:translate-y-0 transition-transform duration-300">{img.name}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>

      </div>
    </div>
  );
};

export default Features;