import React from 'react';
import { MapPin, Phone, Instagram, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-8">
        
        <div className="flex flex-col items-center md:items-start">
            <h3 className="font-black text-2xl tracking-tighter uppercase mb-2">Arte em 4 Patas</h3>
            <p className="text-gray-400 text-sm">© 2024 Arte em 4 Patas Store. Todos os direitos reservados.</p>
        </div>

        <div className="flex flex-col md:flex-row gap-8 text-center md:text-left">
            <div className="flex items-center gap-3 text-gray-600">
                <MapPin size={20} className="text-brand-yellow" />
                <span>Rua das Flores, 123, Lisboa</span>
            </div>
            <div className="flex items-center gap-3 text-gray-600">
                <Phone size={20} className="text-brand-yellow" />
                <span>+351 912 345 678</span>
            </div>
        </div>

        <div className="flex gap-4">
            <a href="#" className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-brand-yellow hover:text-white transition-colors">
                <Instagram size={20} />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-brand-yellow hover:text-white transition-colors">
                <Facebook size={20} />
            </a>
        </div>

      </div>
    </footer>
  );
};

export default Footer;