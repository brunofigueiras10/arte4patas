import React from 'react';
import { PawPrint } from 'lucide-react';

const Navbar: React.FC = () => {
  return (
    <nav className="w-full flex justify-center py-6 px-4 md:px-12 absolute top-0 z-50">
      <div className="flex items-center justify-between w-full max-w-7xl">
        
        {/* Logo */}
        <div className="flex items-center gap-2">
           {/* Simple text logo like reference */}
          <span className="font-bold text-2xl tracking-tight text-gray-900">Arte em 4 Patas</span>
        </div>

        {/* Links - Centered */}
        <div className="hidden md:flex items-center gap-10 text-sm font-medium text-gray-600">
          <a href="#" className="hover:text-brand-yellow transition-colors">Home</a>
          <a href="#" className="hover:text-brand-yellow transition-colors">Serviços</a>
          <a href="#" className="hover:text-brand-yellow transition-colors">Preços</a>
          <a href="#" className="hover:text-brand-yellow transition-colors">Contactos</a>
        </div>

        {/* CTA - Black Button like reference */}
        <div className="hidden md:block">
          <button className="bg-gray-900 text-white px-8 py-3 rounded-xl font-semibold text-sm hover:bg-brand-yellow hover:text-white transition-all shadow-lg">
            Começar Agora
          </button>
        </div>
        
        {/* Mobile Menu Icon (Placeholder) */}
        <div className="md:hidden">
            <div className="space-y-1.5 cursor-pointer">
                <span className="block w-6 h-0.5 bg-gray-800"></span>
                <span className="block w-6 h-0.5 bg-gray-800"></span>
                <span className="block w-6 h-0.5 bg-gray-800"></span>
            </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;